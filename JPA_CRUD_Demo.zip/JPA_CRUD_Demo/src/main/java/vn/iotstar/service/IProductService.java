package vn.iotstar.service;

import java.util.List;
import vn.iotstar.entity.Product;

public interface IProductService {
    void insert(Product product);
    void update(Product product);
    void delete(int productId);
    Product findById(int productId);
    List<Product> findAll();
    List<Product> findTop10();
    List<Product> findAll(int page, int pageSize);
    int count();
}