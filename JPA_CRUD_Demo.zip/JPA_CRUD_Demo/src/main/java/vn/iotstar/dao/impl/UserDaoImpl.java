package vn.iotstar.dao.impl;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;
import vn.iotstar.config.JpaConfig;
import vn.iotstar.dao.IUserDao;
import vn.iotstar.entity.User;

public class UserDaoImpl implements IUserDao {

    @Override
    public void insert(User user) {
        EntityManager en = JpaConfig.getEntityManager();
        EntityTransaction trans = en.getTransaction();
        try {
            trans.begin();
            en.persist(user);
            trans.commit();
        } catch (Exception e) {
            if (trans.isActive()) {
                trans.rollback();
            }
            throw e;
        } finally {
            en.close();
        }
    }

    @Override
    public void update(User user) {
        EntityManager en = JpaConfig.getEntityManager();
        EntityTransaction trans = en.getTransaction();
        try {
            trans.begin();
            en.merge(user);
            trans.commit();
        } catch (Exception e) {
            if (trans.isActive()) {
                trans.rollback();
            }
            throw e;
        } finally {
            en.close();
        }
    }

    @Override
    public User findByEmail(String email) {
        EntityManager en = JpaConfig.getEntityManager();
        try {
            TypedQuery<User> query = en.createQuery("SELECT u FROM User u WHERE u.email = :email", User.class);
            query.setParameter("email", email);
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        } finally {
            en.close();
        }
    }

    @Override
    public User findByUsername(String username) {
        EntityManager en = JpaConfig.getEntityManager();
        try {
            TypedQuery<User> query = en.createQuery("SELECT u FROM User u WHERE u.username = :username", User.class);
            query.setParameter("username", username);
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        } finally {
            en.close();
        }
    }

    @Override
    public void updatePassword(String email, String newPassword) {
        EntityManager en = JpaConfig.getEntityManager();
        EntityTransaction trans = en.getTransaction();
        try {
            trans.begin();
            
            TypedQuery<User> query = en.createQuery("SELECT u FROM User u WHERE u.email = :email", User.class);
            query.setParameter("email", email);
            User user = query.getSingleResult();
            
            if (user != null) {
                user.setPassword(newPassword);
                en.merge(user);
            }
            
            trans.commit();
        } catch (Exception e) {
            if (trans.isActive()) {
                trans.rollback();
            }
            e.printStackTrace();
        } finally {
            en.close();
        }
    }
}