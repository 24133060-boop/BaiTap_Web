package vn.iotstar.controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.iotstar.entity.Product;
import vn.iotstar.service.IProductService;
import vn.iotstar.service.impl.ProductServiceImpl;

@WebServlet(urlPatterns = { "/product", "/product/detail" })
public class UserProductController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    IProductService productService = new ProductServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getRequestURI();

        if (url.contains("/product/detail")) {
            int id = Integer.parseInt(req.getParameter("id"));
            Product product = productService.findById(id);

            req.setAttribute("product", product);
            req.getRequestDispatcher("/views/product-detail.jsp").forward(req, resp);

        } else {
            // Hiển thị 6 sản phẩm mỗi trang theo Mục 4.3
            int page = 1;
            int pageSize = 6;

            if (req.getParameter("page") != null) {
                try {
                    page = Integer.parseInt(req.getParameter("page"));
                } catch (Exception e) {
                    page = 1;
                }
            }

            List<Product> listProduct = productService.findAll(page, pageSize);
            int totalProducts = productService.count();
            int endPage = (int) Math.ceil((double) totalProducts / pageSize);

            req.setAttribute("productList", listProduct);
            req.setAttribute("endPage", endPage);
            req.setAttribute("currentPage", page);

            req.getRequestDispatcher("/views/product-user-list.jsp").forward(req, resp);
        }
    }
}