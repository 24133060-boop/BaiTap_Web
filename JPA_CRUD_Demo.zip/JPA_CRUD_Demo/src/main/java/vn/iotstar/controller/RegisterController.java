package vn.iotstar.controller;

import java.io.IOException;
import java.util.Random;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.iotstar.dao.impl.UserDaoImpl;
import vn.iotstar.entity.User;
import vn.iotstar.util.EmailUtil;

@WebServlet(urlPatterns = { "/register" })
public class RegisterController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDaoImpl userDao = new UserDaoImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String username = req.getParameter("username");
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        if (userDao.findByUsername(username) != null || userDao.findByEmail(email) != null) {
            req.setAttribute("error", "Username hoặc Email đã tồn tại!");
            req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
            return;
        }

        String otp = String.format("%06d", new Random().nextInt(999999));

        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        user.setStatus(false);
        user.setCode(otp);

        userDao.insert(user);
        EmailUtil.sendEmail(email, "Kích hoạt tài khoản", "Mã OTP kích hoạt tài khoản của bạn là: <b>" + otp + "</b>");

        req.setAttribute("email", email);
        req.setAttribute("type", "REGISTER");
        req.getRequestDispatcher("/views/verify-otp.jsp").forward(req, resp);
    }
}