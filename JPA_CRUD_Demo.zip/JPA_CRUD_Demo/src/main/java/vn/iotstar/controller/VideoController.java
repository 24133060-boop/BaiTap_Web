package vn.iotstar.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import vn.iotstar.entity.Category;
import vn.iotstar.entity.Video;
import vn.iotstar.service.ICategoryService;
import vn.iotstar.service.IVideoService;
import vn.iotstar.service.impl.CategoryServiceImpl;
import vn.iotstar.service.impl.VideoServiceImpl;

@MultipartConfig
@WebServlet(urlPatterns = { "/admin/videos", "/admin/video/add", "/admin/video/insert", "/admin/video/edit", "/admin/video/update", "/admin/video/delete" })
public class VideoController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private IVideoService videoService = new VideoServiceImpl();
    private ICategoryService categoryService = new CategoryServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getRequestURI();
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        if (url.contains("/admin/videos")) {
            int page = 1;
            int pageSize = 3;
            if (req.getParameter("page") != null) {
                try {
                    page = Integer.parseInt(req.getParameter("page"));
                } catch (Exception e) {
                    page = 1;
                }
            }
            List<Video> listVideo = videoService.findAll(page, pageSize);
            int count = videoService.count();
            int endPage = (int) Math.ceil((double) count / pageSize);

            req.setAttribute("listVideo", listVideo);
            req.setAttribute("endPage", endPage);
            req.setAttribute("currentPage", page);
            req.getRequestDispatcher("/views/admin/video-list.jsp").forward(req, resp);

        } else if (url.contains("/admin/video/add")) {
            List<Category> listCategory = categoryService.findAll();
            req.setAttribute("listCategory", listCategory);
            req.getRequestDispatcher("/views/admin/video-add.jsp").forward(req, resp);

        } else if (url.contains("/admin/video/edit")) {
            String id = req.getParameter("id");
            Video video = videoService.findById(id);
            List<Category> listCategory = categoryService.findAll();

            req.setAttribute("video", video);
            req.setAttribute("listCategory", listCategory);
            req.getRequestDispatcher("/views/admin/video-edit.jsp").forward(req, resp);

        } else if (url.contains("/admin/video/delete")) {
            String id = req.getParameter("id");
            try {
                videoService.delete(id);
            } catch (Exception e) {
                e.printStackTrace();
            }
            resp.sendRedirect(req.getContextPath() + "/admin/videos");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getRequestURI();
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        if (url.contains("/admin/video/insert") || url.contains("/admin/video/update")) {
            boolean isUpdate = url.contains("/admin/video/update");
            
            String videoId = req.getParameter("videoId");
            String title = req.getParameter("title");
            String description = req.getParameter("description");
            
            String viewsStr = req.getParameter("views");
            int views = (viewsStr != null && !viewsStr.trim().isEmpty()) ? Integer.parseInt(viewsStr.trim()) : 0;
            
            String activeStr = req.getParameter("active");
            int active = (activeStr != null && !activeStr.trim().isEmpty()) ? Integer.parseInt(activeStr.trim()) : 1;
            
            String categoryIdStr = req.getParameter("categoryId");
            int categoryId = (categoryIdStr != null && !categoryIdStr.trim().isEmpty()) ? Integer.parseInt(categoryIdStr.trim()) : 0;

            Video video = isUpdate ? videoService.findById(videoId) : new Video();
            if (video == null) {
                video = new Video();
            }
            
            video.setVideoId(videoId);
            video.setTitle(title);
            video.setDescription(description);
            video.setViews(views);
            video.setActive(active);

            if (categoryId > 0) {
                Category category = categoryService.findById(categoryId);
                video.setCategory(category);
            }

            try {
                Part filePart = req.getPart("poster");
                if (filePart != null && filePart.getSize() > 0) {
                    String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
                    String uploadPath = getServletContext().getRealPath("") + File.separator + "images";
                    File uploadDir = new File(uploadPath);
                    if (!uploadDir.exists()) uploadDir.mkdir();
                    filePart.write(uploadPath + File.separator + fileName);
                    video.setPoster(fileName);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (isUpdate) {
                videoService.update(video);
            } else {
                videoService.insert(video);
            }

            resp.sendRedirect(req.getContextPath() + "/admin/videos");
        }
    }
}