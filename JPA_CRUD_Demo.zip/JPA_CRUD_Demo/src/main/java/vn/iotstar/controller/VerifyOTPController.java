package vn.iotstar.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(urlPatterns = { "/verify-otp", "/verifyOTP" })
public class VerifyOTPController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/views/verify-otp.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        
        // Lấy mã OTP người dùng nhập vào form
        String inputOtp = req.getParameter("otp");
        
        HttpSession session = req.getSession();
        String sessionOtp = (String) session.getAttribute("otp");

        // In ra console để debug trực tiếp
        System.out.println("OTP Nhập vào: " + inputOtp);
        System.out.println("OTP trong Session: " + sessionOtp);

        if (inputOtp != null) {
            inputOtp = inputOtp.trim();
        }

        if (sessionOtp != null && sessionOtp.trim().equals(inputOtp)) {
            // Xác thực thành công -> Xóa OTP khỏi Session
            session.removeAttribute("otp");
            
            // Chuyển sang trang đặt lại mật khẩu mới hoặc Đăng nhập thành công
            req.getRequestDispatcher("/views/reset-password.jsp").forward(req, resp);
        } else {
            req.setAttribute("error", "Mã OTP không chính xác! Vui lòng kiểm tra lại.");
            req.getRequestDispatcher("/views/verify-otp.jsp").forward(req, resp);
        }
    }
}