package vn.iotstar.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import vn.iotstar.entity.Category;
import vn.iotstar.service.ICategoryService;
import vn.iotstar.service.impl.CategoryServiceImpl;

@MultipartConfig
@WebServlet(urlPatterns = { "/admin/categories", "/admin/category/add", "/admin/category/insert",
        "/admin/category/edit", "/admin/category/update", "/admin/category/delete" })
public class CategoryController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Đường dẫn lưu ảnh cố định
    public static final String UPLOAD_DIR = "C:\\Upload_1";
    public ICategoryService cateService = new CategoryServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        String url = req.getRequestURI();

        if (url.contains("/admin/categories")) {
            List<Category> list = cateService.findAll();
            req.setAttribute("listcate", list);
            req.getRequestDispatcher("/views/admin/category-list.jsp").forward(req, resp);
        } else if (url.contains("/admin/category/add")) {
            req.getRequestDispatcher("/views/admin/category-add.jsp").forward(req, resp);
        } else if (url.contains("/admin/category/edit")) {
            int id = Integer.parseInt(req.getParameter("id"));
            Category category = cateService.findById(id);
            req.setAttribute("cate", category);
            req.getRequestDispatcher("/views/admin/category-edit.jsp").forward(req, resp);
        } else if (url.contains("/admin/category/delete")) {
            int id = Integer.parseInt(req.getParameter("id"));
            try {
                cateService.delete(id);
            } catch (Exception e) {
                e.printStackTrace();
            }
            resp.sendRedirect(req.getContextPath() + "/admin/categories");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        String url = req.getRequestURI();

        if (url.contains("/admin/category/insert")) {
            Category category = new Category();
            category.setCategoryname(req.getParameter("categoryname"));
            category.setStatus(Integer.parseInt(req.getParameter("status")));

            String filename = handleFileUpload(req);
            category.setImages(filename.isEmpty() ? "avatar.png" : filename);

            cateService.insert(category);
            resp.sendRedirect(req.getContextPath() + "/admin/categories");

        } else if (url.contains("/admin/category/update") || url.contains("/admin/category/edit")) {
            String idStr = req.getParameter("categoryId");
            if (idStr == null || idStr.isEmpty()) {
                idStr = req.getParameter("categoryid");
            }

            if (idStr != null && !idStr.isEmpty()) {
                int categoryid = Integer.parseInt(idStr);
                Category category = cateService.findById(categoryid);

                if (category != null) {
                    category.setCategoryname(req.getParameter("categoryname"));
                    category.setStatus(Integer.parseInt(req.getParameter("status")));

                    String filename = handleFileUpload(req);
                    if (!filename.isEmpty()) {
                        category.setImages(filename);
                    }

                    cateService.update(category);
                }
            }
            resp.sendRedirect(req.getContextPath() + "/admin/categories");
        }
    }

    private String handleFileUpload(HttpServletRequest req) {
        try {
            Part part = req.getPart("images");
            if (part == null || part.getSize() == 0) {
                part = req.getPart("images1");
            }

            if (part != null && part.getSize() > 0) {
                String filename = Paths.get(part.getSubmittedFileName()).getFileName().toString();
                if (!filename.isEmpty()) {
                    String ext = filename.substring(filename.lastIndexOf("."));
                    String fname = System.currentTimeMillis() + ext;

                    File uploadDir = new File(UPLOAD_DIR);
                    if (!uploadDir.exists()) uploadDir.mkdirs();

                    part.write(UPLOAD_DIR + File.separator + fname);
                    return fname;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
}