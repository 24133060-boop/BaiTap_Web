package vn.iotstar.controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import vn.iotstar.dao.ICategoryDao;
import vn.iotstar.dao.IProductDao;
import vn.iotstar.dao.impl.CategoryDao;
import vn.iotstar.dao.impl.ProductDaoImpl;
import vn.iotstar.entity.Category;
import vn.iotstar.entity.Product;

@WebServlet(urlPatterns = {
    "/admin/products",
    "/admin/product/add",
    "/admin/product/edit",
    "/admin/product/delete"
})
public class ProductController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    IProductDao productDao = new ProductDaoImpl();
    ICategoryDao categoryDao = new CategoryDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getRequestURI();

        if (url.contains("/admin/products")) {
            int page = 1;
            int pageSize = 3;
            
            if (req.getParameter("page") != null) {
                page = Integer.parseInt(req.getParameter("page"));
            }

            int totalProducts = productDao.count();
            int endPage = (int) Math.ceil((double) totalProducts / pageSize);

            List<Product> listProduct = productDao.findAll(page, pageSize);

            req.setAttribute("listProduct", listProduct);
            req.setAttribute("endPage", endPage);
            req.setAttribute("currentPage", page);
            req.getRequestDispatcher("/views/admin/product-list.jsp").forward(req, resp);

        } else if (url.contains("/admin/product/add")) {
            List<Category> listCategory = categoryDao.findAll();
            req.setAttribute("listCategory", listCategory);
            req.getRequestDispatcher("/views/admin/product-add.jsp").forward(req, resp);

        } else if (url.contains("/admin/product/edit")) {
            int id = Integer.parseInt(req.getParameter("id"));
            Product product = productDao.findById(id);
            List<Category> listCategory = categoryDao.findAll();

            req.setAttribute("product", product);
            req.setAttribute("listCategory", listCategory);
            req.getRequestDispatcher("/views/admin/product-edit.jsp").forward(req, resp);

        } else if (url.contains("/admin/product/delete")) {
            int id = Integer.parseInt(req.getParameter("id"));
            try {
                productDao.delete(id);
            } catch (Exception e) {
                e.printStackTrace();
            }
            resp.sendRedirect(req.getContextPath() + "/admin/products");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getRequestURI();
        req.setCharacterEncoding("UTF-8");

        if (url.contains("/admin/product/add")) {
            String productName = req.getParameter("productName");
            double price = Double.parseDouble(req.getParameter("price"));
            String images = req.getParameter("images");
            String description = req.getParameter("description");
            int categoryId = Integer.parseInt(req.getParameter("categoryId"));

            Category category = categoryDao.findById(categoryId);

            Product product = new Product();
            product.setProductName(productName);
            product.setPrice(price);
            product.setImages(images);
            product.setDescription(description);
            product.setCategory(category);

            productDao.insert(product);
            resp.sendRedirect(req.getContextPath() + "/admin/products");

        } else if (url.contains("/admin/product/edit")) {
            int productId = Integer.parseInt(req.getParameter("productId"));
            String productName = req.getParameter("productName");
            double price = Double.parseDouble(req.getParameter("price"));
            String images = req.getParameter("images");
            String description = req.getParameter("description");
            int categoryId = Integer.parseInt(req.getParameter("categoryId"));

            Category category = categoryDao.findById(categoryId);

            Product product = new Product();
            product.setProductId(productId);
            product.setProductName(productName);
            product.setPrice(price);
            product.setImages(images);
            product.setDescription(description);
            product.setCategory(category);

            productDao.update(product);
            resp.sendRedirect(req.getContextPath() + "/admin/products");
        }
    }
}