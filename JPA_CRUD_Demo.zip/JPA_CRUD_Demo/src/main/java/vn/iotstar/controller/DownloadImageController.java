package vn.iotstar.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = { "/image" })
public class DownloadImageController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String fileName = req.getParameter("fname");
        if (fileName == null || fileName.trim().isEmpty()) return;

        File uploadDir = new File(CategoryController.UPLOAD_DIR);
        File file = new File(uploadDir, fileName);

        // Nếu file nguyên bản không tồn tại, tự động quét tìm file khớp tên có đuôi .jpg, .png...
        if (!file.exists()) {
            File[] matchingFiles = uploadDir.listFiles((dir, name) -> name.startsWith(fileName));
            if (matchingFiles != null && matchingFiles.length > 0) {
                file = matchingFiles[0];
            }
        }

        if (file.exists()) {
            // Tự động lấy MIME type chuẩn (image/jpeg, image/png...)
            String mimeType = getServletContext().getMimeType(file.getName());
            if (mimeType == null) {
                mimeType = "image/jpeg";
            }
            resp.setContentType(mimeType);

            try (FileInputStream in = new FileInputStream(file);
                 OutputStream out = resp.getOutputStream()) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = in.read(buffer)) != -1) {
                    out.write(buffer, 0, bytesRead);
                }
            }
        }
    }
}