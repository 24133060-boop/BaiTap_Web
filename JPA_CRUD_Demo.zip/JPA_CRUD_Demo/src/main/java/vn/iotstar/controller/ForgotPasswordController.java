package vn.iotstar.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import vn.iotstar.util.EmailUtil;

@WebServlet(urlPatterns = { "/forgot-password", "/forgotpass", "/forgotPassword" })
public class ForgotPasswordController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/views/forgot-password.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        
        String email = req.getParameter("email");
        
        // Tạo mã OTP ngẫu nhiên 6 chữ số
        String otp = String.valueOf((int) ((Math.random() * (999999 - 100000)) + 100000));
        
        // IN MÃ OTP TRỰC TIẾP RA CONSOLE ECLIPSE ĐỂ LẤY MÃ TEST NGAY
        System.out.println("==============================================");
        System.out.println("MÃ OTP XÁC NHẬN CỦA BẠN LÀ: " + otp);
        System.out.println("==============================================");
        
        // Soạn nội dung Email dạng HTML
        String emailContent = "<h3>Mã OTP Quên Mật Khẩu</h3>"
                            + "<p>Mã xác nhận của bạn là: <b style='color:red; font-size: 18px;'>" + otp + "</b></p>"
                            + "<p>Mã này có hiệu lực trong vài phút. Vui lòng không chia sẻ cho ai khác.</p>";
        
        // Lưu OTP và Email vào Session để đối chiếu ở bước nhập OTP
        req.getSession().setAttribute("otp", otp);
        req.getSession().setAttribute("email", email);
        
        // Thử gửi Email thực tế
        boolean isSent = EmailUtil.sendEmail(email, "MÃ XÁC NHẬN OTP - QUÊN MẬT KHẨU", emailContent);
        
        if (isSent) {
            req.setAttribute("message", "Mã OTP đã được gửi đến email thành công!");
        } else {
            req.setAttribute("message", "Không thể gửi mail (có thể do Gmail bị giới hạn), hãy lấy mã OTP trực tiếp tại Console Eclipse!");
        }
        
        // Luôn chuyển sang trang nhập mã OTP để bạn tiếp tục test
        req.getRequestDispatcher("/views/verify-otp.jsp").forward(req, resp);
    }
}