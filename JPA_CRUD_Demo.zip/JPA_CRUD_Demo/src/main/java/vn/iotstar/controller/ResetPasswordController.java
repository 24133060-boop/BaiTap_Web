package vn.iotstar.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import vn.iotstar.dao.impl.UserDaoImpl;

@WebServlet(urlPatterns = { "/reset-password", "/resetPassword" })
public class ResetPasswordController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Gọi thẳng UserDaoImpl vì dự án chưa tạo UserService
    UserDaoImpl userDao = new UserDaoImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/views/reset-password.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        
        String newPassword = req.getParameter("password");
        HttpSession session = req.getSession();
        String email = (String) session.getAttribute("email");

        if (email != null && newPassword != null && !newPassword.trim().isEmpty()) {
            try {
                // Gọi hàm cập nhật mật khẩu từ UserDaoImpl
                userDao.updatePassword(email, newPassword);
                
                // Xóa email khỏi session sau khi hoàn tất
                session.removeAttribute("email");
                
                req.setAttribute("message", "Đổi mật khẩu thành công! Vui lòng đăng nhập lại.");
                req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
                return;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        req.setAttribute("error", "Đổi mật khẩu thất bại! Vui lòng thử lại.");
        req.getRequestDispatcher("/views/reset-password.jsp").forward(req, resp);
    }
}