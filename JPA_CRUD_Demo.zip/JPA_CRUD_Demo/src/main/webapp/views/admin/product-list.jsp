<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Danh sách Sản phẩm</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #121212; color: #ffffff; margin: 20px; }
        h2 { color: #ffffff; }
        table { border-collapse: collapse; margin-top: 10px; background-color: #1e1e1e; width: 100%; }
        th, td { border: 1px solid #444; padding: 10px; text-align: center; }
        th { background-color: #2a2a2a; color: #ffffff; }
        .pagination { display: flex; list-style: none; padding: 0; margin-top: 15px; }
        .pagination a { padding: 8px 16px; text-decoration: none; border: 1px solid #444; margin: 0 4px; color: white; background-color: #2a2a2a; border-radius: 4px; }
        .pagination a.active { background-color: #0d6efd; color: white; border: 1px solid #0d6efd; }
        img { object-fit: cover; border-radius: 4px; }
    </style>
</head>
<body>
    <h2>DANH SÁCH SẢN PHẨM</h2>
    <a href="<c:url value='/admin/product/add'/>" style="color: #0d6efd; text-decoration: none; font-weight: bold;">+ Thêm Sản Phẩm Mới</a>
    <br/><br/>

    <%-- XỬ LÝ SỐ TRANG AN TOÀN TRÁNH LỖI CÚ PHÁP EL --%>
    <c:set var="pageNo" value="1" />
    <c:if test="${not empty currentPage}">
        <c:set var="pageNo" value="${currentPage}" />
    </c:if>
    <c:set var="startOrder" value="${(pageNo - 1) * 3}" />

    <table>
        <thead>
            <tr>
                <th>STT</th>
                <th>Hình ảnh</th>
                <th>Tên sản phẩm</th>
                <th>Giá</th>
                <th>Danh mục</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach items="${listProduct}" var="prod" varStatus="loop">
                <tr>
                    <td>${startOrder + loop.index + 1}</td>
                    <td>
                        <c:choose>
                            <%-- DÙNG THƯ VIỆN fn:startsWith THAY CHO METHOD CALL TRỰC TIẾP ĐỂ HẾT BÁO LỖI STS --%>
                            <c:when test="${prod.images != null && (fn:startsWith(prod.images, 'http://') || fn:startsWith(prod.images, 'https://'))}">
                                <img height="80" width="100" src="${prod.images}" alt="${prod.productName}" />
                            </c:when>
                            <c:otherwise>
                                <c:url value="/image" var="imgUrl">
                                    <c:param name="fname" value="${prod.images}" />
                                </c:url>
                                <img height="80" width="100" src="${imgUrl}" alt="${prod.productName}" />
                            </c:otherwise>
                        </c:choose>
                    </td>
                    <td>${prod.productName}</td>
                    <td>
                        <fmt:formatNumber value="${prod.price}" type="currency" currencySymbol="VNĐ" maxFractionDigits="0"/>
                    </td>
                    <td>${prod.category.categoryname}</td>
                    <td>
                        <a href="<c:url value='/admin/product/edit?id=${prod.productId}'/>" style="color: #0d6efd;">Sửa</a> | 
                        <a href="<c:url value='/admin/product/delete?id=${prod.productId}'/>" style="color: #dc3545;" onclick="return confirm('Bạn có chắc muốn xóa sản phẩm này?')">Xóa</a>
                    </td>
                </tr>
            </c:forEach>
        </tbody>
    </table>

    <br/>
    <!-- Thanh Phân Trang -->
    <div class="pagination">
        <c:forEach begin="1" end="${endPage}" var="i">
            <c:set var="activeClass" value="" />
            <c:if test="${pageNo == i}">
                <c:set var="activeClass" value="active" />
            </c:if>
            <a href="<c:url value='/admin/products?page=${i}'/>" class="${activeClass}">${i}</a>
        </c:forEach>
    </div>
</body>
</html>