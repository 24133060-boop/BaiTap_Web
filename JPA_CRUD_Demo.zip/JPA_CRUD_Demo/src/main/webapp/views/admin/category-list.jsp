<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Danh Sách Danh Mục</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #121212; color: #ffffff; margin: 20px; }
        h2 { color: #ffffff; }
        .btn-add { display: inline-block; padding: 10px 15px; background-color: #198754; color: white; text-decoration: none; border-radius: 5px; font-weight: bold; margin-bottom: 15px; }
        table { border-collapse: collapse; width: 100%; background-color: #1e1e1e; }
        th, td { border: 1px solid #444; padding: 12px; text-align: center; }
        th { background-color: #2a2a2a; color: #ffffff; }
        .status-active { color: #25cff2; font-weight: bold; }
        img { object-fit: cover; border-radius: 4px; }
    </style>
</head>
<body>

    <h2>DANH SÁCH DANH MỤC</h2>
    <a href="<c:url value='/admin/category/add'/>" class="btn-add">Thêm Danh Mục Mới</a>

    <%-- TỰ ĐỘNG LẤY TÊN BIẾN TỪ CONTROLLER ĐỂ HẾT TRỐNG BẢNG --%>
    <c:set var="dataList" value="${categoryList}" />
    <c:if test="${empty dataList}">
        <c:set var="dataList" value="${listcate}" />
    </c:if>
    <c:if test="${empty dataList}">
        <c:set var="dataList" value="${categories}" />
    </c:if>

    <table>
        <thead>
            <tr>
                <th>STT</th>
                <th>Hình ảnh</th>
                <th>Tên danh mục</th>
                <th>Trạng thái</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <c:choose>
                <c:when test="${not empty dataList}">
                    <c:forEach items="${dataList}" var="cate" varStatus="loop">
                        <tr>
                            <%-- HIỂN THỊ STT TỰ TĂNG LIÊN TỤC 1, 2, 3, 4 --%>
                            <td>${loop.index + 1}</td>
                            <td>
                                <c:choose>
                                    <%-- DÙNG fn:startsWith ĐỂ KHÔNG BỊ BÁO LỖI STS DÒNG 52 --%>
                                    <c:when test="${cate.images != null && (fn:startsWith(cate.images, 'http://') || fn:startsWith(cate.images, 'https://'))}">
                                        <img height="80" width="100" src="${cate.images}" alt="${cate.categoryname}" />
                                    </c:when>
                                    <c:otherwise>
                                        <c:url value="/image" var="imgUrl">
                                            <c:param name="fname" value="${cate.images}" />
                                        </c:url>
                                        <img height="80" width="100" src="${imgUrl}" alt="${cate.categoryname}" />
                                    </c:otherwise>
                                </c:choose>
                            </td>
                            <td>${cate.categoryname}</td>
                            <td>
                                <span class="status-active">${cate.status == 1 ? 'Hoạt động' : 'Khóa'}</span>
                            </td>
                            <td>
                                <a href="<c:url value='/admin/category/edit?id=${cate.categoryId}'/>" style="color: #0d6efd; text-decoration: none;">Sửa</a> | 
                                <a href="<c:url value='/admin/category/delete?id=${cate.categoryId}'/>" style="color: #dc3545; text-decoration: none;" onclick="return confirm('Bạn có chắc muốn xóa?')">Xóa</a>
                            </td>
                        </tr>
                    </c:forEach>
                </c:when>
                <c:otherwise>
                    <tr>
                        <td colspan="5" style="color: #888; font-style: italic;">Chưa có dữ liệu danh mục.</td>
                    </tr>
                </c:otherwise>
            </c:choose>
        </tbody>
    </table>

</body>
</html>x