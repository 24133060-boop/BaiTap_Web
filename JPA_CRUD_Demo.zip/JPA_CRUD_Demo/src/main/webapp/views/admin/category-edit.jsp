<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Chỉnh Sửa Danh Mục</title>
<style>
    .form-group { margin-bottom: 15px; }
    label { display: block; margin-bottom: 5px; font-weight: bold; }
    input[type="text"], select { width: 300px; padding: 8px; }
    img { margin-top: 10px; border-radius: 4px; object-fit: cover; }
</style>
</head>
<body style="background-color: #121212; color: #fff; font-family: Arial, sans-serif; padding: 20px;">

    <h2>CHỈNH SỬA DANH MỤC</h2>

    <form action="<c:url value='/admin/category/update'/>" method="post" enctype="multipart/form-data">
        
        <!-- Truyền ID danh mục ẩn về server -->
        <input type="hidden" name="categoryId" value="${cate.categoryId}" />

        <div class="form-group">
            <label>Tên danh mục:</label>
            <input type="text" name="categoryname" value="${cate.categoryname}" required />
        </div>

        <div class="form-group">
            <label>Hình ảnh hiện tại:</label><br>
            <c:choose>
                <c:when test="${cate.images != null && cate.images.startsWith('http')}">
                    <img src="${cate.images}" width="120" height="90" />
                </c:when>
                <c:when test="${cate.images != null && !cate.images.isEmpty()}">
                    <c:url value="/image?fname=${cate.images}" var="imgUrl"/>
                    <img src="${imgUrl}" width="120" height="90" />
                </c:when>
                <c:otherwise>
                    <p style="color: #888;">Chưa có ảnh</p>
                </c:otherwise>
            </c:choose>
        </div>

        <div class="form-group">
            <label>Chọn ảnh mới (nếu muốn thay đổi):</label>
            <input type="file" name="images" accept="image/*" />
        </div>

        <div class="form-group">
            <label>Trạng thái:</label>
            <select name="status">
                <option value="1" ${cate.status == 1 ? 'selected' : ''}>Hoạt động</option>
                <option value="0" ${cate.status == 0 ? 'selected' : ''}>Khóa</option>
            </select>
        </div>

        <button type="submit" style="padding: 8px 20px; cursor: pointer;">Cập nhật</button>
        <a href="<c:url value='/admin/categories'/>" style="color: #ff6666; margin-left: 10px;">Hủy</a>
    </form>

</body>
</html>