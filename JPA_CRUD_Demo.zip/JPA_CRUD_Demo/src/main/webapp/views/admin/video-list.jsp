<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Quản lý Video</title>
    <style>
        body { background-color: #121212; color: #ffffff; font-family: Arial, sans-serif; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; border: 1px solid #444; }
        th, td { border: 1px solid #444; padding: 10px; text-align: left; }
        th { background-color: #1e1e1e; }
        .btn-add { background-color: #0d6efd; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; display: inline-block; }
        .pagination { display: flex; list-style: none; padding: 0; margin-top: 15px; }
        .pagination a { padding: 8px 16px; text-decoration: none; border: 1px solid #444; margin: 0 4px; color: white; }
        .pagination a.active { background-color: #0d6efd; border-color: #0d6efd; }
    </style>
</head>
<body>
    <h2>Quản lý Video</h2>
    <a href="<c:url value='/admin/video/add'/>" class="btn-add">Thêm Video Mới</a>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Poster</th>
                <th>Tiêu đề</th>
                <th>Lượt xem</th>
                <th>Danh mục</th>
                <th>Trạng thái</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach items="${listVideo}" var="vid">
                <tr>
                    <td>${vid.videoId}</td>
                    <td>
                        <c:if test="${not empty vid.poster}">
                            <img height="60" width="80" src="<c:url value='/images/${vid.poster}'/>" alt="poster" />
                        </c:if>
                    </td>
                    <td>${vid.title}</td>
                    <td>${vid.views}</td>
                    <td>${vid.category != null ? vid.category.categoryname : 'N/A'}</td>
                    <td>${vid.active == 1 ? 'Hoạt động' : 'Khóa'}</td>
                    <td>
                        <a href="<c:url value='/admin/video/edit?id=${vid.videoId}'/>" style="color: #6ea8fe;">Sửa</a> | 
                        <a href="<c:url value='/admin/video/delete?id=${vid.videoId}'/>" style="color: #ea868f;" onclick="return confirm('Xóa video này?')">Xóa</a>
                    </td>
                </tr>
            </c:forEach>
            <c:if test="${empty listVideo}">
                <tr>
                    <td colspan="7" style="text-align: center;">Không có dữ liệu video nào.</td>
                </tr>
            </c:if>
        </tbody>
    </table>

    <div class="pagination">
        <c:forEach begin="1" end="${endPage}" var="i">
            <a href="<c:url value='/admin/videos?page=${i}'/>" class="${currentPage == i ? 'active' : ''}">${i}</a>
        </c:forEach>
    </div>
</body>
</html>