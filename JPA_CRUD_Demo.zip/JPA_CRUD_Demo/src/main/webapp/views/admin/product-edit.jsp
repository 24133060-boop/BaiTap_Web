<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cập nhật Sản Phẩm</title>
    <style>
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input, .form-group select, .form-group textarea { width: 300px; padding: 8px; }
    </style>
</head>
<body>
    <h2>CẬP NHẬT SẢN PHẨM</h2>
    <form action="<c:url value='/admin/product/edit'/>" method="post">
        <!-- Input hidden giữ lại Product ID -->
        <input type="hidden" name="productId" value="${product.productId}" />

        <div class="form-group">
            <label>Tên sản phẩm:</label>
            <input type="text" name="productName" value="${product.productName}" required />
        </div>
        
        <div class="form-group">
            <label>Giá bán (VNĐ):</label>
            <!-- Sử dụng fmt:formatNumber với pattern "0" để loại bỏ ký tự E (2.0E7 -> 20000000) -->
            <fmt:formatNumber value="${product.price}" pattern="0" var="formattedPrice" />
            <input type="number" step="0.01" name="price" value="${formattedPrice}" required />
        </div>
        
        <div class="form-group">
            <label>Tên file hình ảnh:</label>
            <input type="text" name="images" value="${product.images}" />
        </div>
        
        <div class="form-group">
            <label>Mô tả sản phẩm:</label>
            <textarea name="description" rows="4">${product.description}</textarea>
        </div>
        
        <div class="form-group">
            <label>Danh mục sản phẩm:</label>
            <select name="categoryId" required>
                <c:forEach items="${listCategory}" var="cate">
                    <option value="${cate.categoryId}" ${cate.categoryId == product.category.categoryId ? 'selected' : ''}>
                        ${cate.categoryname}
                    </option>
                </c:forEach>
            </select>
        </div>
        
        <button type="submit">Cập nhật</button>
        <a href="<c:url value='/admin/products'/>">Hủy / Quay lại</a>
    </form>
</body>
</html>