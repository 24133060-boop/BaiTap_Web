<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Thêm Sản Phẩm Mới</title>
    <style>
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input, .form-group select, .form-group textarea { width: 300px; padding: 8px; }
    </style>
</head>
<body>
    <h2>THÊM SẢN PHẨM MỚI</h2>
    <form action="<c:url value='/admin/product/add'/>" method="post">
        <div class="form-group">
            <label>Tên sản phẩm:</label>
            <input type="text" name="productName" required />
        </div>
        
        <div class="form-group">
            <label>Giá bán (VNĐ):</label>
            <input type="number" step="0.01" name="price" required />
        </div>
        
        <div class="form-group">
            <label>Tên file hình ảnh (ví dụ: laptop.png):</label>
            <input type="text" name="images" />
        </div>
        
        <div class="form-group">
            <label>Mô tả sản phẩm:</label>
            <textarea name="description" rows="4"></textarea>
        </div>
        
        <div class="form-group">
            <label>Danh mục sản phẩm:</label>
            <select name="categoryId" required>
                <option value="">-- Chọn danh mục --</option>
                <c:forEach items="${listCategory}" var="cate">
                    <option value="${cate.categoryId}">${cate.categoryname}</option>
                </c:forEach>
            </select>
        </div>
        
        <button type="submit">Lưu sản phẩm</button>
        <a href="<c:url value='/admin/products'/>">Hủy / Quay lại</a>
    </form>
</body>
</html>