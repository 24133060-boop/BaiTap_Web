<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cập Nhật Video</title>
    <style>
        body { background-color: #121212; color: #ffffff; font-family: Arial, sans-serif; padding: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="text"], input[type="number"], textarea, select { width: 100%; max-width: 400px; padding: 8px; background-color: #2a2a2a; color: #fff; border: 1px solid #444; border-radius: 4px; box-sizing: border-box; }
        textarea { height: 100px; }
        .btn-submit { background-color: #0d6efd; color: white; padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; }
    </style>
</head>
<body>
    <h2>CẬP NHẬT VIDEO</h2>
    <form action="<c:url value='/admin/video/update'/>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>Video ID:</label>
            <input type="text" name="videoId" value="${video.videoId}" readonly style="background-color: #444;" />
        </div>

        <div class="form-group">
            <label>Tiêu đề:</label>
            <input type="text" name="title" value="${video.title}" required />
        </div>

        <div class="form-group">
            <label>Mô tả:</label>
            <textarea name="description">${video.description}</textarea>
        </div>

        <div class="form-group">
            <label>Poster hiện tại:</label><br/>
            <c:if test="${not empty video.poster}">
                <img height="80" width="100" src="<c:url value='/images/${video.poster}'/>" alt="poster" /><br/>
            </c:if>
            <input type="file" name="poster" />
        </div>

        <div class="form-group">
            <label>Lượt xem:</label>
            <input type="number" name="views" value="${video.views}" required />
        </div>

        <div class="form-group">
            <label>Danh mục:</label>
            <select name="categoryId" required>
                <option value="">-- Chọn danh mục --</option>
                <c:forEach items="${listCategory}" var="cate">
                    <option value="${cate.categoryId}" ${video.category != null && video.category.categoryId == cate.categoryId ? 'selected' : ''}>
                        ${cate.categoryname}
                    </option>
                </c:forEach>
            </select>
        </div>

        <div class="form-group">
            <label>Trạng thái:</label>
            <input type="radio" name="active" value="1" ${video.active == 1 ? 'checked' : ''} /> Hoạt động
            <input type="radio" name="active" value="0" ${video.active == 0 ? 'checked' : ''} /> Khóa
        </div>

        <button type="submit" class="btn-submit">Cập Nhật Video</button>
    </form>
</body>
</html>