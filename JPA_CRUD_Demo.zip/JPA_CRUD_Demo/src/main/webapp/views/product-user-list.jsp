<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Danh Sách Sản Phẩm</title>
<style>
    body { 
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
        background: #121212; 
        color: #fff; 
        padding: 20px; 
    }
    h2 { 
        text-align: center; 
        color: #4CAF50; 
        margin-bottom: 30px; 
        font-size: 2em;
    }
    
    /* Lưới hiển thị 3 cột sản phẩm */
    .product-grid { 
        display: grid; 
        grid-template-columns: repeat(3, 1fr); 
        gap: 25px; 
        max-width: 1050px; 
        margin: 0 auto; 
    }
    
    .product-card { 
        background: #1e1e1e; 
        padding: 20px; 
        border-radius: 10px; 
        text-align: center; 
        border: 1px solid #333; 
        box-shadow: 0 4px 10px rgba(0,0,0,0.4);
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        transition: transform 0.2s ease;
        position: relative;
    }
    .product-card:hover {
        transform: translateY(-5px);
        border-color: #4CAF50;
    }
    
    /* Huy hiệu STT nổi góc trái thẻ */
    .stt-badge {
        position: absolute;
        top: 10px;
        left: 10px;
        background-color: #007bff;
        color: #ffffff;
        font-weight: bold;
        font-size: 0.9em;
        padding: 4px 10px;
        border-radius: 20px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.5);
        z-index: 10;
    }
    
    .product-card img { 
        width: 100%; 
        height: 200px; 
        object-fit: cover; 
        border-radius: 6px; 
        background-color: #2a2a2a;
    }
    
    .product-title {
        font-size: 1.1em;
        margin: 15px 0 10px 0;
        font-weight: bold;
        min-height: 45px;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
    
    .price { 
        color: #28a745; 
        font-weight: bold; 
        font-size: 1.2em; 
        margin-bottom: 15px; 
    }
    
    .btn-detail { 
        display: inline-block; 
        padding: 10px 20px; 
        background: #ffc107; 
        color: #000; 
        text-decoration: none; 
        border-radius: 5px; 
        font-weight: bold; 
        transition: 0.3s;
    }
    .btn-detail:hover { 
        background: #e0a800; 
    }
    
    /* Thanh phân trang */
    .pagination { 
        margin-top: 40px; 
        text-align: center; 
    }
    .pagination a { 
        color: #fff; 
        padding: 10px 18px; 
        text-decoration: none; 
        border: 1px solid #444; 
        margin: 0 4px; 
        border-radius: 5px; 
        font-weight: bold;
    }
    .pagination a:hover { 
        background: #333; 
    }
    .pagination a.active { 
        background: #007bff; 
        border-color: #007bff; 
    }
</style>
</head>
<body>

    <h2>DANH SÁCH SẢN PHẨM</h2>
    
    <%-- XỬ LÝ CÔNG THỨC BÙ SỐ TRANG NỐI TIẾP (6 sản phẩm / trang) --%>
    <c:set var="pageNo" value="1" />
    <c:if test="${not empty currentPage}">
        <c:set var="pageNo" value="${currentPage}" />
    </c:if>
    <c:set var="startOrder" value="${(pageNo - 1) * 6}" />

    <div class="product-grid">
        <c:forEach items="${productList}" var="p" varStatus="loop">
            <div class="product-card">
                <!-- STT nối tiếp (1-6 cho trang 1, 7-12 cho trang 2) -->
                <div class="stt-badge">STT: ${startOrder + loop.index + 1}</div>

                <!-- Xử lý hiển thị đường dẫn ảnh: HTTP URL hoặc tên file trong ổ C:\Upload_1 qua ImageServlet -->
                <c:choose>
                    <c:when test="${p.images.startsWith('http')}">
                        <c:set var="imgUrl" value="${p.images}"/>
                    </c:when>
                    <c:otherwise>
                        <c:url value="/image?fname=${p.images}" var="imgUrl"/>
                    </c:otherwise>
                </c:choose>
                
                <img src="${imgUrl}" 
                     alt="${p.productName}" 
                     onerror="this.onerror=null; this.src='https://dummyimage.com/250x200/2a2a2a/ffffff&text=No+Image';">
                
                <div class="product-title">${p.productName}</div>
                
                <div class="price">
                    <fmt:formatNumber value="${p.price}" pattern="#,###"/> VNĐ
                </div>
                
                <div>
                    <a href="${pageContext.request.contextPath}/product/detail?id=${p.productId}" class="btn-detail">Xem chi tiết</a>
                </div>
            </div>
        </c:forEach>
    </div>

    <!-- Thanh phân trang -->
    <div class="pagination">
        <c:forEach begin="1" end="${endPage}" var="i">
            <a href="${pageContext.request.contextPath}/product?page=${i}" 
               class="${currentPage == i ? 'active' : ''}">${i}</a>
        </c:forEach>
    </div>

</body>
</html>