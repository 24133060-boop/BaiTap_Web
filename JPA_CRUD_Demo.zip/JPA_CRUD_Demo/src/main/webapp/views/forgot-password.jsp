<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Quên Mật Khẩu</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #121212;
        color: #ffffff;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }
    .form-container {
        background-color: #1e1e1e;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.5);
        width: 350px;
        text-align: center;
    }
    h2 {
        margin-bottom: 20px;
    }
    .form-group {
        margin-bottom: 15px;
        text-align: left;
    }
    label {
        display: block;
        margin-bottom: 5px;
        color: #ccc;
    }
    input[type="email"] {
        width: 100%;
        padding: 10px;
        border: 1px solid #333;
        border-radius: 4px;
        background-color: #252525;
        color: #fff;
        box-sizing: border-box;
    }
    button {
        width: 100%;
        padding: 10px;
        background-color: #ffc107;
        border: none;
        border-radius: 4px;
        color: #000;
        font-weight: bold;
        cursor: pointer;
        margin-top: 10px;
    }
    button:hover {
        background-color: #e0a800;
    }
    .message {
        color: #ff4d4d;
        margin-bottom: 15px;
    }
</style>
</head>
<body>

    <div class="form-container">
        <h2>Quên Mật Khẩu</h2>
        
        <c:if test="${not empty error}">
            <div class="message">${error}</div>
        </c:if>

        <form action="${pageContext.request.contextPath}/forgot-password" method="post">
            <div class="form-group">
                <label for="email">Nhập Email tài khoản:</label>
                <input type="email" id="email" name="email" required placeholder="example@gmail.com">
            </div>
            <button type="submit">Gửi OTP qua Mail</button>
        </form>
    </div>

</body>
</html>