<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head><title>Đăng nhập</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="container mt-5" style="max-width: 400px;">
    <h2>Đăng nhập</h2>
    <c:if test="${param.msg == 'activated'}"><div class="alert alert-success">Kích hoạt thành công! Hãy đăng nhập.</div></c:if>
    <c:if test="${param.msg == 'reset_success'}"><div class="alert alert-success">Đổi mật khẩu thành công!</div></c:if>
    <c:if test="${not empty error}"><div class="alert alert-danger">${error}</div></c:if>
    <form action="${pageContext.request.contextPath}/login" method="post">
        <div class="mb-3"><label>Username:</label><input type="text" name="username" class="form-control" required></div>
        <div class="mb-3"><label>Password:</label><input type="password" name="password" class="form-control" required></div>
        <button type="submit" class="btn btn-primary w-100 mb-2">Đăng nhập</button>
        <a href="${pageContext.request.contextPath}/forgotPassword">Quên mật khẩu?</a> | 
        <a href="${pageContext.request.contextPath}/register">Đăng ký mới</a>
    </form>
</body>
</html>