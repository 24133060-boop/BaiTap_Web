<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head><title>Xác thực OTP</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="container mt-5" style="max-width: 400px;">
    <h2>Nhập mã OTP</h2>
    <p>Mã OTP đã được gửi đến: <b>${email}</b></p>
    <c:if test="${not empty error}"><div class="alert alert-danger">${error}</div></c:if>
    <form action="${pageContext.request.contextPath}/verifyOTP" method="post">
        <input type="hidden" name="email" value="${email}">
        <input type="hidden" name="type" value="${type}">
        <div class="mb-3"><input type="text" name="otp" class="form-control" placeholder="Nhập mã 6 chữ số" required></div>
        <button type="submit" class="btn btn-success w-100">Xác nhận</button>
    </form>
</body>
</html>