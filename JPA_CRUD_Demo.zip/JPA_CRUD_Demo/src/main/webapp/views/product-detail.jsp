<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Chi Tiết Sản Phẩm</title>
<style>
    body { 
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
        background-color: #121212; 
        color: #ffffff; 
        padding: 40px; 
    }
    .detail-container { 
        display: flex; 
        gap: 30px; 
        background: #1e1e1e; 
        padding: 30px; 
        border-radius: 10px; 
        max-width: 850px; 
        margin: 40px auto; 
        border: 1px solid #333; 
        box-shadow: 0 4px 20px rgba(0,0,0,0.6);
        align-items: center;
    }
    .product-img { 
        width: 280px; 
        height: 280px; 
        object-fit: cover; 
        border-radius: 8px; 
        border: 1px solid #444;
    }
    .info { 
        flex: 1; 
    }
    .info h2 { 
        color: #4CAF50; 
        margin-top: 0; 
        font-size: 1.8em;
    }
    .price { 
        color: #28a745; 
        font-size: 1.5em; 
        font-weight: bold; 
        margin: 15px 0; 
    }
    .description {
        line-height: 1.6;
        color: #ccc;
        margin-bottom: 25px;
        background: #252525;
        padding: 12px;
        border-radius: 6px;
    }
    .btn-back { 
        display: inline-block; 
        padding: 10px 20px; 
        background: #007bff; 
        color: #fff; 
        text-decoration: none; 
        border-radius: 5px; 
        font-weight: bold; 
        transition: 0.3s;
    }
    .btn-back:hover { 
        background: #0056b3; 
    }
</style>
</head>
<body>

    <div class="detail-container">
        <!-- Khối hiển thị ảnh sản phẩm -->
        <img class="product-img" 
             src="${product.images}" 
             alt="${product.productName}" 
             onerror="this.src='https://via.placeholder.com/280?text=No+Image';">
        
        <!-- Khối thông tin sản phẩm -->
        <div class="info">
            <h2>${product.productName}</h2>
            
            <!-- Đã sửa định dạng giá tiền chuẩn VNĐ không bị lẻ ,00 -->
            <div class="price">
                Giá: <fmt:formatNumber value="${product.price}" pattern="#,###"/> VNĐ
            </div>
            
            <div class="description">
                <strong>Mô tả sản phẩm:</strong><br>
                ${product.description != null ? product.description : 'Đang cập nhật mô tả...'}
            </div>
            
            <a href="${pageContext.request.contextPath}/product" class="btn-back">← Quay lại danh sách</a>
        </div>
    </div>

</body>
</html>