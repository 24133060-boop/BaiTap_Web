<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Trang Chủ - Top Sản Phẩm Mới</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 30px;
        background-color: #121212;
        color: #ffffff;
    }
    h2 {
        color: #ffffff;
        margin-bottom: 20px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
        background-color: #1e1e1e;
    }
    th, td {
        border: 1px solid #333333;
        padding: 12px;
        text-align: left;
    }
    th {
        background-color: #2d2d2d;
        color: #ffffff;
        font-weight: bold;
    }
    tr:nth-child(even) {
        background-color: #252525;
    }
    tr:hover {
        background-color: #333333;
    }
    .empty-msg {
        color: #888888;
        font-style: italic;
        padding: 15px;
    }
</style>
</head>
<body>

    <h2>Danh Sách 10 Sản Phẩm Mới Nhất</h2>

    <table>
        <thead>
            <tr>
                <th>STT</th>
                <th>Mã SP</th>
                <th>Tên Sản Phẩm</th>
                <th>Đơn Giá</th>
                <th>Mô Tả</th>
            </tr>
        </thead>
        <tbody>
            <c:choose>
                <c:when test="${not empty top10Products}">
                    <c:forEach items="${top10Products}" var="p" varStatus="STT">
                        <tr>
                            <td>${STT.index + 1}</td>
                            <td>${p.productId}</td>
                            <td>${p.productName}</td>
                            <td>
                                <fmt:formatNumber value="${p.price}" pattern="#,##0" /> VNĐ
                            </td>
                            <td>${p.description}</td>
                        </tr>
                    </c:forEach>
                </c:when>
                <c:otherwise>
                    <tr>
                        <td colspan="5" class="empty-msg" style="text-align: center;">
                            Chưa có sản phẩm nào trong hệ thống. Vui lòng thêm sản phẩm từ trang Admin!
                        </td>
                    </tr>
                </c:otherwise>
            </c:choose>
        </tbody>
    </table>

</body>
</html>