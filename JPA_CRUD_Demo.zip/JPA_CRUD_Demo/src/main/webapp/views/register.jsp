<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head><title>Đăng ký Tài Khoản</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="container mt-5" style="max-width: 400px;">
    <h2>Đăng ký Tài Khoản</h2>
    <c:if test="${not empty error}"><div class="alert alert-danger">${error}</div></c:if>
    <form action="${pageContext.request.contextPath}/register" method="post">
        <div class="mb-3"><label>Username:</label><input type="text" name="username" class="form-control" required></div>
        <div class="mb-3"><label>Email:</label><input type="email" name="email" class="form-control" required></div>
        <div class="mb-3"><label>Mật khẩu:</label><input type="password" name="password" class="form-control" required></div>
        <button type="submit" class="btn btn-primary w-100">Đăng ký & Nhận OTP</button>
    </form>
</body>
</html>